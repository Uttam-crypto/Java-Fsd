package Phase1practiseproject;

import java.util.Random;

public class Practise_Project2 {
	public static void main(String[] args) {
        int[] array = {12, 3, 5, 7, 4, 19, 26, 8, 1};
        int k = 4; // Find the fourth smallest element

        int result = quickSelect(array, 0, array.length - 1, k - 1);

        System.out.println("The fourth smallest element is: " + result);
    }

    private static int quickSelect(int[] arr, int low, int high, int k) {
        if (low <= high) {
            int partitionIndex = partition(arr, low, high);

            // If the partitionIndex is equal to k, we have found the kth smallest element
            if (partitionIndex == k) {
                return arr[partitionIndex];
            }

            // If k is less than the partition index, search in the left subarray
            if (k < partitionIndex) {
                return quickSelect(arr, low, partitionIndex - 1, k);
            }
            // If k is greater than the partition index, search in the right subarray
            else {
                return quickSelect(arr, partitionIndex + 1, high, k);
            }
        }

        return -1; // This should not happen if the input is valid
    }

    private static int partition(int[] arr, int low, int high) {
        // Choose a random pivot to avoid worst-case scenarios
        Random rand = new Random();
        int randomIndex = rand.nextInt(high - low + 1) + low;
        swap(arr, randomIndex, high);

        int pivot = arr[high];
        int i = low - 1;

        for (int j = low; j < high; j++) {
            if (arr[j] <= pivot) {
                i++;
                swap(arr, i, j);
            }
        }

        swap(arr, i + 1, high);
        return i + 1;
    }

    private static void swap(int[] arr, int i, int j) {
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }

}
