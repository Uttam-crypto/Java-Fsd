package Phase1practiseproject;

public class Practise_Project1 {
	public static void main(String[] args) {
        int[] array = {1, 2, 3, 4, 5, 6, 7, 8, 9};
        int steps = 5;

        System.out.println("Original Array: ");
        printArray(array);

        rightRotateArray(array, steps);

        System.out.println("\nArray after right rotation by " + steps + " steps: ");
        printArray(array);
    }

    // Function to right rotate an array by specified steps
    private static void rightRotateArray(int[] arr, int steps) {
        int n = arr.length;
        steps = steps % n; // To handle cases where steps > array length

        // Create a temporary array to store rotated elements
        int[] temp = new int[n];

        // Copy elements to temp array in rotated order
        for (int i = 0; i < n; i++) {
            temp[(i + steps) % n] = arr[i];
        }

        // Copy elements back to original array
        for (int i = 0; i < n; i++) {
            arr[i] = temp[i];
        }
    }

    // Function to print an array
    private static void printArray(int[] arr) {
        for (int num : arr) {
            System.out.print(num + " ");
        }
        System.out.println();
    }

}
