package SearchingAndSorting;

import java.util.Scanner;

public class Practise_Project1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Take user input for the array size
        System.out.print("Enter the size of the array: ");
        int size = scanner.nextInt();

        // Create an array of integers
        int[] array = new int[size];

        // Take user input for array elements
        System.out.println("Enter the elements of the array:");
        for (int i = 0; i < size; i++) {
            array[i] = scanner.nextInt();
        }

        // Take user input for the element to search
        System.out.print("Enter the element to search: ");
        int searchElement = scanner.nextInt();

        // Perform linear search
        int index = linearSearch(array, searchElement);

        // Display the result
        if (index != -1) {
            System.out.println("Element found at index: " + index);
        } else {
            System.out.println("Element not found in the array.");
        }
    }

    // Linear search algorithm
    private static int linearSearch(int[] array, int searchElement) {
        // Iterate through the array
        for (int i = 0; i < array.length; i++) {
            // Check if the current element is equal to the search element
            if (array[i] == searchElement) {
                return i; // Return the index if found
            }
        }
        // Return -1 if the element is not found
        return -1;
    }
}
