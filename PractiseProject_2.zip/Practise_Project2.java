package SearchingAndSorting;

import java.util.Scanner;

public class Practise_Project2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Take user input for the array size
        System.out.print("Enter the size of the sorted array: ");
        int size = scanner.nextInt();

        // Create a sorted array of integers
        int[] sortedArray = new int[size];

        // Take user input for sorted array elements
        System.out.println("Enter the sorted elements of the array:");
        for (int i = 0; i < size; i++) {
            sortedArray[i] = scanner.nextInt();
        }

        // Take user input for the element to search
        System.out.print("Enter the element to search: ");
        int searchElement = scanner.nextInt();

        // Perform binary search
        int index = binarySearch(sortedArray, searchElement);

        // Display the result
        if (index != -1) {
            System.out.println("Element found at index: " + index);
        } else {
            System.out.println("Element not found in the array.");
        }
    }

    // Binary search algorithm
    private static int binarySearch(int[] sortedArray, int searchElement) {
        int low = 0;
        int high = sortedArray.length - 1;

        while (low <= high) {
            int mid = low + (high - low) / 2;

            // Check if the middle element is equal to the search element
            if (sortedArray[mid] == searchElement) {
                return mid; // Return the index if found
            }

            // If the search element is greater, ignore the left half
            if (sortedArray[mid] < searchElement) {
                low = mid + 1;
            }
            // If the search element is smaller, ignore the right half
            else {
                high = mid - 1;
            }
        }

        // Return -1 if the element is not found
        return -1;
    }
}