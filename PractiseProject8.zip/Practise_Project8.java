package Phase1practiseproject;

import java.util.Stack;

public class Practise_Project8 {
    public static void main(String[] args) {
        // Creating a stack
        Stack<Integer> stack = new Stack<>();

        // Inserting elements into the stack (push operation)
        System.out.println("Pushing elements onto the stack:");
        stack.push(10);
        stack.push(20);
        stack.push(30);
        stack.push(40);

        // Displaying the stack after pushing elements
        displayStack(stack);

        // Removing elements from the stack (pop operation)
        System.out.println("\nPopping elements from the stack:");
        int poppedElement = stack.pop();
        System.out.println("Popped element: " + poppedElement);

        // Displaying the stack after popping an element
        displayStack(stack);
    }

    // Function to display the elements of the stack
    private static void displayStack(Stack<Integer> stack) {
        if (stack.isEmpty()) {
            System.out.println("Stack is empty");
            return;
        }

        System.out.println("Elements in the stack:");
        for (int element : stack) {
            System.out.print(element + " ");
        }
        System.out.println();
    }
}

