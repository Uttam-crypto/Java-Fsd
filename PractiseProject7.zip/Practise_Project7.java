package Phase1practiseproject;

class Node {
    int data;
    Node next;
    Node prev;

    Node(int data) {
        this.data = data;
        this.next = null;
        this.prev = null;
    }
}

class DoublyLinkedList {
    Node head;

    // Function to insert a new node at the end of the doubly linked list
    void insert(int newData) {
        Node newNode = new Node(newData);

        if (head == null) {
            head = newNode;
        } else {
            Node temp = head;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = newNode;
            newNode.prev = temp;
        }
    }

    // Function to traverse the doubly linked list in forward direction
    void traverseForward() {
        System.out.println("Doubly Linked List (Forward):");
        Node temp = head;
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }
        System.out.println();
    }

    // Function to traverse the doubly linked list in backward direction
    void traverseBackward() {
        System.out.println("Doubly Linked List (Backward):");
        Node temp = head;
        while (temp.next != null) {
            temp = temp.next;
        }

        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.prev;
        }
        System.out.println();
    }
}

public class Practise_Project7 {
    public static void main(String[] args) {
        DoublyLinkedList doublyList = new DoublyLinkedList();

        // Insert elements into the doubly linked list
        doublyList.insert(10);
        doublyList.insert(20);
        doublyList.insert(30);
        doublyList.insert(40);

        // Traverse the doubly linked list in forward direction
        doublyList.traverseForward();

        // Traverse the doubly linked list in backward direction
        doublyList.traverseBackward();
    }
}
