package SearchingAndSorting;

import java.util.Arrays;
import java.util.Scanner;

public class Practise_Project3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Take user input for the array size
        System.out.print("Enter the size of the sorted array: ");
        int size = scanner.nextInt();

        // Create a sorted array of integers
        int[] sortedArray = new int[size];

        // Take user input for sorted array elements
        System.out.println("Enter the sorted elements of the array:");
        for (int i = 0; i < size; i++) {
            sortedArray[i] = scanner.nextInt();
        }

        // Take user input for the element to search
        System.out.print("Enter the element to search: ");
        int searchElement = scanner.nextInt();

        // Perform exponential search
        int index = exponentialSearch(sortedArray, searchElement);

        // Display the result
        if (index != -1) {
            System.out.println("Element found at index: " + index);
        } else {
            System.out.println("Element not found in the array.");
        }
    }

    // Exponential search algorithm
    private static int exponentialSearch(int[] sortedArray, int searchElement) {
        if (sortedArray[0] == searchElement) {
            return 0; // Element found at index 0
        }

        int i = 1;
        while (i < sortedArray.length && sortedArray[i] <= searchElement) {
            i *= 2; // Double the position index

            // Perform a binary search in the current range
            int result = Arrays.binarySearch(sortedArray, i / 2, Math.min(i, sortedArray.length), searchElement);

            if (result >= 0) {
                return result; // Element found in the binary search
            }
        }

        // Return -1 if the element is not found
        return -1;
    }
}

