package practise_project9;

public interface Second {
	default void show() 
    { 
        System.out.println("Default Second"); 
    } 
}
