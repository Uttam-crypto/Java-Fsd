package Phase1practiseproject;

import java.util.Scanner;

class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class CircularLinkedList {
    Node head;

    // Function to insert a new node at the end of the circular linked list
    void insertAtEnd(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
            newNode.next = head;
        } else {
            Node temp = head;
            while (temp.next != head) {
                temp = temp.next;
            }
            temp.next = newNode;
            newNode.next = head;
        }
    }

    // Function to display the circular linked list
    void display() {
        if (head == null) {
            System.out.println("Circular Linked List is empty.");
            return;
        }

        Node temp = head;
        do {
            System.out.print(temp.data + " ");
            temp = temp.next;
        } while (temp != head);
        System.out.println();
    }
}

public class Practise_Project6 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        CircularLinkedList circularList = new CircularLinkedList();

        // Inserting initial elements into the circular linked list
        circularList.insertAtEnd(1);
        circularList.insertAtEnd(2);
        circularList.insertAtEnd(3);

        System.out.println("Initial Circular Linked List:");
        circularList.display();

        // Inserting a new element based on user input
        System.out.print("Enter the data for the new element: ");
        int newData = scanner.nextInt();
        circularList.insertAtEnd(newData);

        System.out.println("Circular Linked List after insertion:");
        circularList.display();

        scanner.close();
    }
}

