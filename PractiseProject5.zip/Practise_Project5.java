package Phase1practiseproject;
class Node {
    int data;
    Node next;

    Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class SinglyLinkedList {
    Node head;

    SinglyLinkedList() {
        this.head = null;
    }

    // Function to insert a new node at the end of the linked list
    void insert(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
        } else {
            Node temp = head;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = newNode;
        }
    }

    // Function to delete the first occurrence of a key in the linked list
    void delete(int key) {
        Node current = head;
        Node prev = null;

        // If the key is in the head node
        if (current != null && current.data == key) {
            head = current.next;
            return;
        }

        // Search for the key to delete
        while (current != null && current.data != key) {
            prev = current;
            current = current.next;
        }

        // If the key is not present in the linked list
        if (current == null) {
            System.out.println("Key not found in the linked list.");
            return;
        }

        // Delete the node with the key
        prev.next = current.next;
    }

    // Function to display the linked list
    void display() {
        Node temp = head;
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }
        System.out.println();
    }
}

public class Practise_Project5 {
	public static void main(String[] args) {
	SinglyLinkedList list = new SinglyLinkedList();

    // Insert elements into the linked list
    list.insert(10);
    list.insert(20);
    list.insert(30);
    list.insert(40);

    System.out.println("Linked List before deletion:");
    list.display();

    int keyToDelete = 20;
    list.delete(keyToDelete);

    System.out.println("Linked List after deleting the first occurrence of " + keyToDelete + ":");
    list.display();
	}

}
